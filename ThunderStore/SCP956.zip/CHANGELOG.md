## 0.3.0
- 11 candles instead of 10 for cake
- Changes to cake model
- Enabled spawning pinata for all behaviors
- Secret mechanic for cake :3
- Height of child players changed from 0.8 to 0.7
- Other small tweaks

## 0.2.5
- Small fix that might fix compatibility with Deathnote mod

## 0.2.4
- Fixed small game breaking bug oops

## 0.2.3
- Added more candles to cake
- Some temp bug fixes

## 0.2.2
- Temp fix for bugging out when landing on a moon

## 0.2.1
- Added configs to disable SCP-956, SCP-559, and SCP-330 (In case you want to use just the items or enemy)
- Small description fix

## 0.2.0
- Added SCP-330
- Added candy effects
- Added custom status effects
- SCP-559 now works correctly
- Added more config options
- SCP559 now heals you a little bit when you eat it