## 0.2.1
- Added configs to disable SCP-956, SCP-559, and SCP-330 (In case you want to use just the items or enemy)
- Small description fix

## 0.2.0
- Added SCP-330
- Added candy effects
- Added custom status effects
- SCP-559 now works correctly
- Added more config options
- SCP559 now heals you a little bit when you eat it